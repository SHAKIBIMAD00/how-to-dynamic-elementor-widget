<?php
/**
 * Plugin Name: Custom Elementor Widget
 * Description: A basic custom widget for Elementor that outputs a dynamic title.
 * Version: 1.0
 * Author: Shakibul Hasan
 */

function register_custom_elementor_widgets() {
    require_once(__DIR__ . '/elementor-widgets/class-business-widget.php');
}
add_action('elementor/widgets/widgets_registered', 'register_custom_elementor_widgets');
