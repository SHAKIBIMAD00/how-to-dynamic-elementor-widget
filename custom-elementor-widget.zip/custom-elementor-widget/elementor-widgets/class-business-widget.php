<?php
class Elementor_Business_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'business_widget';
    }

    public function get_title() {
        return __('Business Widget', 'textdomain');
    }

    public function get_icon() {
        return 'eicon-info-box';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'textdomain'),
        ]);

        $this->add_control('title', [
            'label' => __('Title', 'textdomain'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('Business Title', 'textdomain'),
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo '<h2>' . $settings['title'] . '</h2>';
    }
}
\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Elementor_Business_Widget());
